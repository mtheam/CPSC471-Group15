<?php $__env->startSection('content'); ?>
<div class="masthead">
  <div class="container h-100">
	<div class="row h-100 align-items-center">
	  <div style="top: 5%;" class="col-12">
		<h1 class="font-weight-bold"><font color="black">COFFEE & TEA FOR YOU</font></h1>
		<p class="lead"><font color="black">A better cup, every day, your way. </font></p>
		<!--<a href="/shop" class="btn btn-primary" role="button" >Shop</a>-->
		<div class="container">
			<div><h1><font color="black">Hello, <?php echo e($user->name); ?>. Here is your Cart</font></h1></div>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-md-4">
          <div class="thumbnail">
            <h3><font color="black">Order #<?php echo e($order->orderid); ?></font></h3>
            <div class="caption">
              <p><font color="black">Total Cost: $<?php echo e($order->totalcost); ?></font></p>
              <p><font color="black">Credit Card Company Used: <?php echo e($order->creditcardcompanyname); ?></font><p>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div>
    <form method="post" action="" accept-charset="UTF-8">
      <!--<button type="submit" class="btn btn-sm btn-primary"><font color="black">Ship</font></button>-->
      <?php echo e(csrf_field()); ?>

    </form>
	  </div>
	</div>
  </div>
</div>

<?php echo $__env->make('layouts.welcome_signedin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffeeshop\resources\views/orders.blade.php ENDPATH**/ ?>