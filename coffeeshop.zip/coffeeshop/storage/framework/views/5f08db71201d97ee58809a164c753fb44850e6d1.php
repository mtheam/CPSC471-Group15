<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
			<p><font color="black">User Profile</font></p>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffeeshop\resources\views/user/profile.blade.php ENDPATH**/ ?>