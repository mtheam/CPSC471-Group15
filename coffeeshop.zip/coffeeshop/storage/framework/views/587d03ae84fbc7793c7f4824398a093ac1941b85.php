<?php $__env->startSection('content'); ?>
<div class="masthead">
  <div class="container h-100">
	<div class="row h-100 align-items-center">
	  <div style="top: 5%;" class="col-12">
		<h1 class="font-weight-bold"><font color="black">COFFEE & TEA FOR YOU</font></h1>
		<p class="lead"><font color="black">A better cup, every day, your way. </font></p>
		<!--<a href="/shop" class="btn btn-primary" role="button" >Shop</a>-->
		<div class="container">
			<?php $__currentLoopData = $items->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="row">
				<?php $__currentLoopData = $itemChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-sm-6 col-md-4">
					<div class="thumbnail">
						<h3><font color="black"><?php echo e($item->name); ?></font></h3>
						<img src="<?php echo e($item->url); ?>" width=250px alt="..." style="">
						<div class="caption">
							<p><font color="black"><?php echo e($item->productcategory); ?></font></p>
							<p><font color="black">$<?php echo e($item->price); ?></font></p>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	  </div>
	</div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffeeshop\resources\views/index.blade.php ENDPATH**/ ?>