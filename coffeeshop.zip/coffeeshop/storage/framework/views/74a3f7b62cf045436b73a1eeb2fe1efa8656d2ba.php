
<!-- Full Page Image Header with Vertically Centered Content -->
<?php echo $__env->yieldContent('content'); ?>

<?php /**PATH C:\xampp\htdocs\coffeeshop\resources\views/layouts/body.blade.php ENDPATH**/ ?>