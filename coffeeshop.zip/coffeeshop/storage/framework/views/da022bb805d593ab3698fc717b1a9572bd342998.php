<?php $__env->startSection('content'); ?>
<div class="masthead">
  <div class="container h-100">
	<div class="row h-100 align-items-center">
	  <div style="top: 5%;" class="col-12">
		<h1 class="font-weight-bold"><font color="black">COFFEE & TEA FOR YOU</font></h1>
		<p class="lead"><font color="black">A better cup, every day, your way. </font></p>
    <h1><font color="black">Hello Admin</font></h1>
    <div class="container">
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-md-4">
          <div class="thumbnail">
            <div class="caption">
              <h3><font color="black">Order Id: <?php echo e($order->orderid); ?></font></h3>
              <div><font color="black" size="+1">Total Cost: <?php echo e($order->totalcost); ?></font></div>
              <div><font color="black" size="+1">Customer Id: <?php echo e($order->customerid); ?></font></div>
              <div><font color="black" size="+1">Customer Username: <?php echo e($order->customerusername); ?></font></div>
              <div><font color="black" size="+1">Credit Card Company Name: <?php echo e($order->creditcardcompanyname); ?></font></div>
              <form method="post" action=<?php echo e('deleteOrder'); ?> accept-charset="UTF-8">
                <input type="hidden"  id="orderid" name="orderid" value="<?php echo e($order->orderid); ?>" />
                <button type="submit" class="btn btn-primary">Delete Order</button>
                <?php echo e(csrf_field()); ?>

              </form>
              <div><br></br></div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
    </div>
		</div>
	  </div>
	</div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.welcome_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffeeshop\resources\views/admin.blade.php ENDPATH**/ ?>