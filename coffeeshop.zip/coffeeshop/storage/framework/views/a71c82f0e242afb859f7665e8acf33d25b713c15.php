<!doctype html>
<html lang="en">
</html>
</head>
	<meta chartset="UTF-8">
	<title>hello</title>
	<?php echo $__env->yieldContent('styles'); ?>
</head>
<body>
	hi
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\coffeeshop\resources\views/master.blade.php ENDPATH**/ ?>