<?php $__env->startSection('content'); ?>
<div class="masthead">
  <div class="container h-100">
	<div class="row h-100 align-items-center">
	  <div style="top: 5%;" class="col-12">
		<h1 class="font-weight-bold"><font color="black">COFFEE & TEA FOR YOU</font></h1>
		<p class="lead"><font color="black">A better cup, every day, your way. </font></p>

		<div class="container">
			<div><h1><font color="black">Hello, <?php echo e($user->name); ?>. Here is your Cart</font></h1></div>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-md-4">
          <div class="thumbnail">
            <h3><font color="black"><?php echo e($item->name); ?></font></h3>
            <img src="<?php echo e($item->url); ?>" width=250px alt="..." style="">
            <div class="caption">
              <p><font color="black"><?php echo e($item->productcategory); ?></font></p>
              <p><font color="black">$<?php echo e($item->price); ?></font></p>
              <div><font color="black">Quantity: <?php echo e($item->quantity); ?></font></div>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <h3><font color="black">Total Cost: $<?php echo e($sum); ?></font></h3>
		</div>
    <form method="post" action=<?php echo e('clearCart'); ?> accept-charset="UTF-8">
      <button type="submit" class="btn btn-sm btn-primary"><font color="black">Clear Shopping Cart</font></button>
      <?php echo e(csrf_field()); ?>

    </form>
    <br></br>
      <?php if($needshippingrecipient == 0): ?>
        <form method="post" action=<?php echo e('addShippingRecipient'); ?> accept-charset="UTF-8">
          <div>
            <div><h2><font color="black">Enter New Shipping Recipient information If Desired</font></h2></div>
            <div class="row">
            <div class="col">
              <label for="username"><font color="black">Name</font></label>
              <input class="form-control" name="name" id="name" placeholder="Enter name">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="city"><font color="black">City</font></label>
              <input class="form-control" name="city" id="city" placeholder="Enter city">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="province"><font color="black">Province</font></label>
              <input class="form-control" name="province" id="province" placeholder="Enter province">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="postalcode"><font color="black">Postal Code</font></label>
              <input class="form-control" name="postalcode" id="postalcode" placeholder="Enter postal code">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="street"><font color="black">Street</font></label>
              <input class="form-control" name="street" id="street" placeholder="Enter street">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="street"><font color="black">Street Number</font></label>
              <input class="form-control" name="streetnumber" id="streetnumber" placeholder="Enter street number">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="apartmentnumber"><font color="black">Apartment Number</font></label>
              <input class="form-control" name="apartmentnumber" id="apartmentnumber" placeholder="Enter apartment number">
            </div>
            </div>
            <button style="margin-top: 5px;" class="btn btn-primary" type="submit">Add Shipping Recipient</button>
            <?php echo e(csrf_field()); ?>

          </div>
        </form>
        <form method="post" action=<?php echo e('createOrder'); ?> accept-charset="UTF-8">
          <div class="form-group">
            <label for "creditcardcompanyname"><font color="black">Credit Card Company Name</font></label>
            <select class="form-control" name="creditcardcompanynameselect">

              <?php $__currentLoopData = $creditcardcompanies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $creditcardcompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option id="creditcardcompanyname" name="creditcardcompanyname" value="<?php echo e($creditcardcompany->name); ?>"><?php echo e($creditcardcompany->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>
          </div>
          <label for "creditcardcompanyname"><font color="black">Shipping Recipient</font></label>
          <select class="form-control" name="shippingrecipientnameselect">
            <?php $__currentLoopData = $shippingrecipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shippingrecipient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option id="shippingrecipientname" name="shippingrecipientname" value="<?php echo e($shippingrecipient->name); ?>">
                  <?php echo e($shippingrecipient->name); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <button type="submit" class="btn btn-sm btn-primary"><font color="black">Create Order</font></button>
          <?php echo e(csrf_field()); ?>

        </form>
      <?php else: ?>
        <form method="post" action=<?php echo e('addShippingRecipient'); ?> accept-charset="UTF-8">
          <div>
            <div><h2><font color="black">Enter Shipping Recipient Information</font></h2></div>
            <div class="row">
            <div class="col">
              <label for="username"><font color="black">Name</font></label>
              <input class="form-control" name="name" id="name" placeholder="Enter name">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="city"><font color="black">City</font></label>
              <input class="form-control" name="city" id="city" placeholder="Enter city">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="province"><font color="black">Province</font></label>
              <input class="form-control" name="province" id="province" placeholder="Enter province">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="postalcode"><font color="black">Postal Code</font></label>
              <input class="form-control" name="postalcode" id="postalcode" placeholder="Enter postal code">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="street"><font color="black">Street</font></label>
              <input class="form-control" name="street" id="street" placeholder="Enter street">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="street"><font color="black">Street Number</font></label>
              <input class="form-control" name="streetnumber" id="streetnumber" placeholder="Enter street number">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="apartmentnumber"><font color="black">Apartment Number</font></label>
              <input class="form-control" name="apartmentnumber" id="apartmentnumber" placeholder="Enter apartment number">
            </div>
            </div>
            <button style="margin-top: 5px;" class="btn btn-primary" type="submit">Add Shipping Recipient</button>
            <?php echo e(csrf_field()); ?>

          </div>
        </form>
      <?php endif; ?>

	  </div>
	</div>
  </div>
</div>

<?php echo $__env->make('layouts.welcome_signedin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\coffeeshop\resources\views/cart.blade.php ENDPATH**/ ?>