<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [ 'uses' => 'IndexController@getIndex', 'as' => 'index']);

/*Route::get('user/signup', ['uses' => 'UserController@getSignup', 'as' => 'user.signup']);*/

Route::post('user/signup', ['uses' => 'UserController@postSignup', 'as' => 'user.signup']);

Route::post('user/signin', ['uses' => 'UserController@postSignin', 'as' => 'user.signin']);

Route::get('user/profile', ['uses' => 'UserController@getProfile', 'as' => 'user.profile']);

Route::get('/shop', [ 'uses' => 'ShopController@getShop', 'as' => 'shop']);

Route::post('addToCart', 'ShopController@postAddToCart');

Route::get('shop', 'ShopController@shop');

Route::get('cart', [ 'uses' => 'CartController@getCartView', 'as' => 'cart']);

Route::post('clearCart', 'CartController@clearShoppingCart');

Route::post('createOrder', 'CartController@createOrder');

Route::post('addShippingRecipient', 'CartController@addShippingRecipient');

Route::get('/order', [ 'uses' => 'OrderController@getOrderView', 'as' => 'order']);

Route::get('/admin', [ 'uses' => 'AdminController@getAdminView', 'as' => 'admin']);

Route::post('deleteOrder', 'AdminController@deleteOrder');
