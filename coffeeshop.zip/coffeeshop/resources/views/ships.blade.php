@extends('layouts.welcome_signedin')


@section('content')
<div class="masthead">
  <div class="container h-100">
	<div class="row h-100 align-items-center">
	  <div style="top: 5%;" class="col-12">
		<h1 class="font-weight-bold"><font color="black">COFFEE & TEA FOR YOU</font></h1>
		<p class="lead"><font color="black">A better cup, every day, your way. </font></p>
		<!--<a href="/shop" class="btn btn-primary" role="button" >Shop</a>-->
		<div class="container">
        <h3><font color="black">Total Cost: ${{$sum}}</font></h3>
        <h3><font color="black">Transaction Processed By: {{$order->creditcardcompanyname}}</font></h3>
		</div>
    <form method="post" action="" accept-charset="UTF-8">
      <!--<button type="submit" class="btn btn-sm btn-primary"><font color="black">Ship</font></button>-->
      {{ csrf_field() }}
    </form>
	  </div>
	</div>
  </div>
</div>
