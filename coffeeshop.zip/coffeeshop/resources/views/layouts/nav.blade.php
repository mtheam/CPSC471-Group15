
<!------Navigation Bar------>
<nav class="navbar navbar-expand-lg navbar-light bg-light shadow fixed-top">
    <div class="container">
      <p><a class="navbar-brand" href="#"><img src="https://5.imimg.com/data5/NH/VC/MY-2623595/coffee-beans-250x250.jpg"></a><big style="font-weight:bold;">The Coffee Co</big></p>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="#signupModal" data-toggle="modal">Sign Up</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#loginModal" data-toggle="modal">Log In</a>
          </li>
        </ul>
      </div>
    </div>
</nav>


