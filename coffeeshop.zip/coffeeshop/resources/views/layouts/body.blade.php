
<!-- Full Page Image Header with Vertically Centered Content -->


