
<!doctype html> 
<html>
	@include('layouts.head')
	<body>
		<div id="app">
			
			@include('layouts.nav')


			<div class="container">
				<p>why wont this work </p>
			</div>
			
		</div>
		


		 <script type="text/javascript" src="{{ URL::asset('js/app.js') }}"></script>

	</body>
</html>


