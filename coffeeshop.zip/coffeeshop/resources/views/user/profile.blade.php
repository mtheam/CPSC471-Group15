@extends('layouts.welcome')

@section('content')
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
			<p><font color="black">User Profile</font></p>
		</div>
	</div>
@endsection
