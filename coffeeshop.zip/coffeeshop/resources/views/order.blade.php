@extends('layouts.welcome_signedin')


@section('content')
<div class="masthead">
  <div class="container h-100">
	<div class="row h-100 align-items-center">
	  <div style="top: 5%;" class="col-12">
		<h1 class="font-weight-bold"><font color="black">COFFEE & TEA FOR YOU</font></h1>
		<p class="lead"><font color="black">A better cup, every day, your way. </font></p>
		<!--<a href="/shop" class="btn btn-primary" role="button" >Shop</a>-->
		<div class="container">
			<div><h1><font color="black">Hello, {{$user->name}}. Here is your order.</font></h1></div>
        @foreach($items as $item)
        <div class="col-sm-6 col-md-4">
          <div class="thumbnail">
            <h3><font color="black">Name: {{ $item->name }}</font></h3>
            <img src="{{ $item->url }}" width=250px alt="..." style="">
            <div class="caption">
              <p><font color="black">Product Category: {{ $item->productcategory }}</font></p>
              <p><font color="black">Price: ${{ $item->price }}</font></p>
              <div><font color="black">Quantity: {{ $item->quantity }}</font></div>
            </div>
          </div>
        </div>
        @endforeach
        <h3><font color="black">Total Cost: ${{$sum}}</font></h3>
        <h3><font color="black">Transaction Processed By: {{$order->creditcardcompanyname}}</font></h3>
        <h3><font color="black">Order will be shipped to: {{$order->shippingrecipientname}}</font></h3>
		</div>
    <form method="post" action="" accept-charset="UTF-8">
      <!--<button type="submit" class="btn btn-sm btn-primary"><font color="black">Ship</font></button>-->
      {{ csrf_field() }}
    </form>
	  </div>
	</div>
  </div>
</div>
