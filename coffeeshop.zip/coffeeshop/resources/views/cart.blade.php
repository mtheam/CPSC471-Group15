@extends('layouts.welcome_signedin')


@section('content')
<div class="masthead">
  <div class="container h-100">
	<div class="row h-100 align-items-center">
	  <div style="top: 5%;" class="col-12">
		<h1 class="font-weight-bold"><font color="black">COFFEE & TEA FOR YOU</font></h1>
		<p class="lead"><font color="black">A better cup, every day, your way. </font></p>

		<div class="container">
			<div><h1><font color="black">Hello, {{$user->name}}. Here is your Cart</font></h1></div>
        @foreach($items as $item)
        <div class="col-sm-6 col-md-4">
          <div class="thumbnail">
            <h3><font color="black">{{ $item->name }}</font></h3>
            <img src="{{ $item->url }}" width=250px alt="..." style="">
            <div class="caption">
              <p><font color="black">{{ $item->productcategory }}</font></p>
              <p><font color="black">${{ $item->price }}</font></p>
              <div><font color="black">Quantity: {{ $item->quantity }}</font></div>
            </div>
          </div>
        </div>
        @endforeach
        <h3><font color="black">Total Cost: ${{$sum}}</font></h3>
		</div>
    <form method="post" action={{'clearCart'}} accept-charset="UTF-8">
      <button type="submit" class="btn btn-sm btn-primary"><font color="black">Clear Shopping Cart</font></button>
      {{ csrf_field() }}
    </form>
    <br></br>
      @if($needshippingrecipient == 0)
        <form method="post" action={{'addShippingRecipient'}} accept-charset="UTF-8">
          <div>
            <div><h2><font color="black">Enter New Shipping Recipient information If Desired</font></h2></div>
            <div class="row">
            <div class="col">
              <label for="username"><font color="black">Name</font></label>
              <input class="form-control" name="name" id="name" placeholder="Enter name">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="city"><font color="black">City</font></label>
              <input class="form-control" name="city" id="city" placeholder="Enter city">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="province"><font color="black">Province</font></label>
              <input class="form-control" name="province" id="province" placeholder="Enter province">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="postalcode"><font color="black">Postal Code</font></label>
              <input class="form-control" name="postalcode" id="postalcode" placeholder="Enter postal code">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="street"><font color="black">Street</font></label>
              <input class="form-control" name="street" id="street" placeholder="Enter street">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="street"><font color="black">Street Number</font></label>
              <input class="form-control" name="streetnumber" id="streetnumber" placeholder="Enter street number">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="apartmentnumber"><font color="black">Apartment Number</font></label>
              <input class="form-control" name="apartmentnumber" id="apartmentnumber" placeholder="Enter apartment number">
            </div>
            </div>
            <button style="margin-top: 5px;" class="btn btn-primary" type="submit">Add Shipping Recipient</button>
            {{csrf_field()}}
          </div>
        </form>
        <form method="post" action={{'createOrder'}} accept-charset="UTF-8">
          <div class="form-group">
            <label for "creditcardcompanyname"><font color="black">Credit Card Company Name</font></label>
            <select class="form-control" name="creditcardcompanynameselect">

              @foreach ($creditcardcompanies as $creditcardcompany)
                <option id="creditcardcompanyname" name="creditcardcompanyname" value="{{$creditcardcompany->name}}">{{ $creditcardcompany->name }}</option>
              @endforeach

            </select>
          </div>
          <label for "creditcardcompanyname"><font color="black">Shipping Recipient</font></label>
          <select class="form-control" name="shippingrecipientnameselect">
            @foreach ($shippingrecipients as $shippingrecipient)
              <option id="shippingrecipientname" name="shippingrecipientname" value="{{$shippingrecipient->name}}">
                  {{ $shippingrecipient->name }}
              </option>
            @endforeach
          </select>
          <button type="submit" class="btn btn-sm btn-primary"><font color="black">Create Order</font></button>
          {{ csrf_field() }}
        </form>
      @else
        <form method="post" action={{'addShippingRecipient'}} accept-charset="UTF-8">
          <div>
            <div><h2><font color="black">Enter Shipping Recipient Information</font></h2></div>
            <div class="row">
            <div class="col">
              <label for="username"><font color="black">Name</font></label>
              <input class="form-control" name="name" id="name" placeholder="Enter name">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="city"><font color="black">City</font></label>
              <input class="form-control" name="city" id="city" placeholder="Enter city">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="province"><font color="black">Province</font></label>
              <input class="form-control" name="province" id="province" placeholder="Enter province">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="postalcode"><font color="black">Postal Code</font></label>
              <input class="form-control" name="postalcode" id="postalcode" placeholder="Enter postal code">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="street"><font color="black">Street</font></label>
              <input class="form-control" name="street" id="street" placeholder="Enter street">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="street"><font color="black">Street Number</font></label>
              <input class="form-control" name="streetnumber" id="streetnumber" placeholder="Enter street number">
            </div>
            </div>
            <div class="row">
            <div class="col">
              <label for="apartmentnumber"><font color="black">Apartment Number</font></label>
              <input class="form-control" name="apartmentnumber" id="apartmentnumber" placeholder="Enter apartment number">
            </div>
            </div>
            <button style="margin-top: 5px;" class="btn btn-primary" type="submit">Add Shipping Recipient</button>
            {{csrf_field()}}
          </div>
        </form>
      @endif

	  </div>
	</div>
  </div>
</div>
