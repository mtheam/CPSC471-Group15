-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: coffee_shop
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `order` (
  `orderid` int(11) NOT NULL,
  `totalcost` float DEFAULT NULL,
  `cartid` int(11) DEFAULT NULL,
  `customerid` int(11) DEFAULT NULL,
  `customerusername` varchar(255) DEFAULT NULL,
  `creditcardcompanyname` varchar(255) DEFAULT NULL,
  `shippingrecipientname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`orderid`),
  KEY `ORDER_SHOPPINGCARTFK` (`cartid`),
  KEY `ORDER_CUSTOMERFK` (`customerid`),
  KEY `ORDER_CREDITCARDCOMPFK` (`creditcardcompanyname`),
  CONSTRAINT `ORDER_CREDITCARDCOMPFK` FOREIGN KEY (`creditcardcompanyname`) REFERENCES `credit_card_company` (`name`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `ORDER_CUSTOMERFK` FOREIGN KEY (`customerid`) REFERENCES `customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `ORDER_SHOPPINGCARTFK` FOREIGN KEY (`cartid`) REFERENCES `shopping_cart` (`cartid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (8,1.94,4,4,'johndoe','RBC','Rafael'),(9,2.03,4,4,'johndoe','RBC','Rafael'),(12,0,4,4,'johndoe','ATB','Aden'),(13,2.99,4,4,'johndoe','ATB','Rafael'),(14,0,4,4,'johndoe','ATB','Aden'),(15,0,4,4,'johndoe','RBC','Rafael'),(16,0,4,4,'johndoe','ATB','Aden'),(17,0,7,7,'newuser','ATB','Aden'),(25,0,4,4,'johndoe','ATB','Aden'),(26,0,8,8,'a','CIBC','a'),(32,0,8,8,'a','ATB','a'),(33,0,8,8,'a','ATB','a'),(34,0,8,8,'a','ATB','a'),(35,0,8,8,'a','ATB','a'),(36,0,8,8,'a','ATB','a'),(37,0.89,8,8,'a','ATB','a'),(38,1.05,8,8,'a','CIBC','ad'),(39,1.95,4,4,'johndoe','ATB','Rafael'),(40,1.88,4,4,'johndoe','CIBC','Rafael'),(41,2.8,9,9,'b','CIBC','b'),(42,0.98,11,11,'r','CIBC','r');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-18 23:55:44
