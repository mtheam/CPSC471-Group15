<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ShopController extends Controller
{
	public function shop(Request $request) {
		$user_id = $request->session()->get('userid'); // get userid from session
		$user = DB::table('user')->where('id', $user_id)->first(); // retrieve the tuple of the user
		$items = DB::table('item')->get(); // get all items from the database

		return view('shop', ['user' => $user, 'items' => $items]); // pass the tuple of user and all items in database
	}
	public function postAddToCart(Request $request) {
		$itemid = $request->input('itemid'); // get item id
		$userid = $request->session()->get('userid'); // get userid from session
		// check if item has already been added to cart
		if(is_null(DB::table('items_in_shopping_cart')->where('cartid' , '=', $userid)->where('itemid', '=', $itemid)->first())){
			DB::table('items_in_shopping_cart')->insert(['cartid' => $userid, 'itemid' => $itemid, 'quantity' => 1]); // add item to cart of user in database
		}
		else {
			// update item quantity in cart of user in database
			$quantity = DB::table('items_in_shopping_cart')->where('cartid' , '=', $userid)->where('itemid', '=', $itemid)->value('quantity') + 1;
			DB::table('items_in_shopping_cart')->where('cartid' , '=', $userid)->where('itemid', '=', $itemid)->update(['quantity' => $quantity]);
		}
		return redirect('/shop'); // redirect pack to shop page
	}

	public function getShop() {
		$items = DB::table('item')->get();
		return view('shop', ['items' => $items]);
	}
}
