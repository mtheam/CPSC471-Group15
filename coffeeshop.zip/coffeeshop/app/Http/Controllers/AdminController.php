<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function getAdminView(){
      $orders = DB::table('order')->get();
      return view('admin', ['orders' => $orders]);
    }

    public function deleteOrder(Request $request) {
      $orderid = $request->input('orderid');
      DB::table('order')->where('orderid', $orderid)->delete();
      return $this->getAdminView();
    }
}
