<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Redirect;

class UserController extends Controller
{
	public function postSignup(Request $request) {
		$this->validate($request, [
			'username' => 'required|unique:user',
			'password' => 'required|min:5',
			'email' => 'email|required|unique:user',
			'name' => 'required'
		]);
		$username = $request->input('username');
		$newId = DB::table('user')->max('Id') + 1;
		DB::table('user')->insert([
			'id' => $newId ,
			'username' => $username,
			'name' => $request->input('name'),
			'password' => $request->input('password'),
			'email' => $request->input('email')
		]);

		DB::table('customer')->insert([
			'Id' => $newId,
			'Username' => $request->input('username'),
		]);

		DB::table('shopping_cart')->insert([
			'cartid' => $newId,
			'customerid' => $newId,
			'customerusername' => $username
		]);

		return redirect()->back();
	}

	public function postSignin(Request $request) {
        $this->validate($request, [
            'email' => 'required',
            'password' => 'required|min:5'
        ]);

				$email = $request->input('email');
				$user = DB::table('user')->where('email', $email)->first();
				$userid = $user->id;
				$request->session()->put('userid', $userid);

				if($request->input('password') != $user->password){
					return redirect('/');
				}
				// User login
				if(!is_null(DB::table('customer')->where('id', $userid)->first())) {
					return redirect('/shop');
				}
				// Admin Login
				else {
					return redirect('/admin');
				}

    }

/*
	public function postSignin(Request $request) {
		$this->validate($request, [
			'email' => 'required',
			'password' => 'required|min:5'
		]);
		$email = $request->input('email');
		$id = DB::table('user')->where('email', $email)->value('id');
		$user = DB::table('user')->where('email', $email)->first();
		//$name = DB::table('user')->where('email', $email)->value('name');
		//session(['user_id' => $id, 'id' => $name]);
		$request->session()->put('user_id', $user->id);

		return redirect('/shop');
	}
*/

	public function getProfile() {
		return view('user.profile');
	}
}
