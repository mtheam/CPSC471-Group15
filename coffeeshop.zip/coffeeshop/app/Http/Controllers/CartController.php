<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CartController extends Controller {

	public function getCartView(Request $request){
		$userid = $request->session()->get('userid'); // get userid from session
		$user = DB::table('user')->where('id', $userid)->first(); // retrieve the tuple of the user
		// get all items from the database
		$items = DB::table('items_in_shopping_cart')
																								->join('item', 'items_in_shopping_cart.itemid', '=', 'item.id')
																								->where('cartid', $userid)
																								->get();
		// Get sum of cart
		$sum = 0;
		foreach($items as $item) {
			$sum = $sum + $item->quantity * $item->price;
		}
		DB::table('shopping_cart')->where('cartid' , '=', $userid)->update(['itemtotal' => $sum]); // Update sum of cart in database


		$shippingrecipients = DB::table('shipping_recipient')
		->join('customer', 'shipping_recipient.customerid', '=', 'customer.id')
		->where('customerid', $userid)
		->get();

		if($shippingrecipients->isEmpty()) {
			$needshippingrecipient = 1;
		}
		else {
			$needshippingrecipient = 0;
		}

		$creditcardcompanies = DB::table('credit_card_company')->get();
		return view('cart', ['user' => $user, 'items' => $items, 'sum' => $sum, 'shippingrecipients' => $shippingrecipients, 'creditcardcompanies' => $creditcardcompanies, 'needshippingrecipient' => $needshippingrecipient]); // pass the tuple of user and all items in database
	}

	public function addShippingRecipient(Request $request) {
		$userid = $request->session()->get('userid'); // get userid from session
		$user = DB::table('user')->where('id', $userid)->first(); // retrieve the tuple of the user

		$name = $request->input('name');
		$city = $request->input('city');
		$province = $request->input('province');
		$postalcode = $request->input('postalcode');
		$street = $request->input('street');
		$streetnumber = $request->input('streetnumber');
		$apartmentnumber = $request->input('apartmentnumber');

		DB::table('shipping_recipient')->insert(['name' => $name,
								 														'customerid' => $userid,
																						'customerusername' => $user->username,
																						'customerid' => $userid,
																						'customerusername' => $user->username,
																						'city' => $city,
																						'province' => $province,
																						'postalcode' => $postalcode,
																						'street' => $street,
																						'streetnumber' => $streetnumber,
																						'apartmentnumber' => $apartmentnumber
															 							]);
		//return $this->getCartView();
		return redirect('/cart');
	}


	public function clearShoppingCart(Request $request){
		$userid = $request->session()->get('userid'); // get userid from session
		$user = DB::table('user')->where('id', $userid)->first(); // retrieve the tuple of the user
		DB::table('items_in_shopping_cart')->where('cartid', '=', $userid)->delete();
		DB::table('shopping_cart')->where('cartid', '=', $userid)->update(['itemtotal' => 0]);
		return redirect('/cart');
	}

	public function createOrder(Request $request) {
		$userid = $request->session()->get('userid'); // get userid from session
		$items = DB::table('items_in_shopping_cart')
																								->join('item', 'items_in_shopping_cart.itemid', '=', 'item.id')
																								->where('cartid', $userid)
																								->get(); // get all items in cart from the database
		$orderid = DB::table('order')->max('orderid') + 1;
		$user = DB::table('user')->where('id', $userid)->first();
		$totalcost = DB::table('shopping_cart')->where('cartid' , '=', $userid)->value('itemtotal');
		$cart = DB::table('shopping_cart')->where('cartid', '=', $userid)->first();
		$creditcardcompanyname = $request->input('creditcardcompanynameselect');

		$shippingrecipientname = $request->input('shippingrecipientnameselect');
		// Create order from shopping cart
		DB::table('order')->insert(['orderid' => $orderid,
		 														'totalcost' => $totalcost,
																'cartid' => $cart->cartid,
																'customerid' => $userid,
																'customerusername' => $user->username,
																'creditcardcompanyname' => $creditcardcompanyname,
																'shippingrecipientname' => $shippingrecipientname
															 ]);

		return redirect('/order');
	}
}
