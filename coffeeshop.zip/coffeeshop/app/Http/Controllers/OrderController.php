<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class OrderController extends Controller {

	public function getOrderView(Request $request){
		$userid = $request->session()->get('userid'); // get userid from session
		$user = DB::table('user')->where('id', $userid)->first();
		$order = DB::table('order')->where('customerid', $userid)->orderBy('orderid','desc')->first(); // retrieve the tuple of the user
		$items = DB::table('items_in_shopping_cart')->join('item', 'items_in_shopping_cart.itemid', '=', 'item.id')
																								->where('cartid', $userid)
																								->get(); // get all items from the database
																								// Clear cart and cart data from database

		// Get sum of cart
		$sum = 0;
		foreach($items as $item) {
			$sum = $sum + $item->quantity * $item->price;
		}

		DB::table('items_in_shopping_cart')->where('cartid', '=', $userid)->delete(); // Delete items of user in shopping cart
		DB::table('shopping_cart')->where('cartid', '=', $userid)->update(['itemtotal' => 0]); // Delete shopping cart of the user

		return view('order', ['user' => $user,
												 	'order' => $order,
													'items' => $items,
													'sum' => $sum
												 ]); // pass the tuple of user and all items in database
	}
}
